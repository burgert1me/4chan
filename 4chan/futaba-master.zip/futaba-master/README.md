futaba
======

http://www.2chan.net/script/